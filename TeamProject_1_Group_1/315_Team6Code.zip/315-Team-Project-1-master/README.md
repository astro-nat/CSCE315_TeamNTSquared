# 315 Team Project 1
Coded in C++<br />
Compiled in Visual Studio<br />
Run on Windows environment<br />
To compile, enter 'make' (or use VS button)<br />
To run, enter './a.out' (or use VS button)<br />
Github Repo: https://github.tamu.edu/nateleake/team-project-1/<br />
